create
    definer = rdsadmin@localhost procedure rds_stop_replication()
BEGIN
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE v_semi_sync ENUM('SOURCE', 'REPLICA', 'NO');
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version(), mysql.rds_replication_service_state(), mysql.rds_is_semi_sync() INTO sql_logging, v_called_by_user, v_mysql_version, v_service_state, v_semi_sync;

  IF v_called_by_user != 'rdsadmin@localhost' AND v_semi_sync = 'REPLICA'
  THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Permission Denied: Replication for Multi-AZ clusters is managed exclusively by RDS.';
  elseif v_service_state = 'OFF' 
  then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave is already stopped or may not be configured. Run SHOW SLAVE STATUS\\G;';
  else 
    
    BEGIN
      DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
      SET @@sql_log_bin=OFF;

      update mysql.rds_replication_status set called_by_user=v_called_by_user,action='stop slave', mysql_version=v_mysql_version where action is not null;
      commit;
      DO SLEEP(1);
      STOP SLAVE;
      SELECT mysql.rds_replication_service_state() INTO v_service_state;
      if v_service_state = 'OFF'
      then
        insert into mysql.rds_history (called_by_user,action,mysql_version) values (v_called_by_user,'stop slave',v_mysql_version);
        commit;
        
        Select 'Slave is now down or disabled' as Message;
      else
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered an error. Run SHOW SLAVE STATUS\\G; to see the error.';
      end if;

      SET @@sql_log_bin=sql_logging;
    END;
  end if;
END;

