create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2023-04-16 17:28:55'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

