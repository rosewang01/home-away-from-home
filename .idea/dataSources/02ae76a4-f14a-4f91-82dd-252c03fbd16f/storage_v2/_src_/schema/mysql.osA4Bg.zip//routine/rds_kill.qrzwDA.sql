create
    definer = rdsadmin@localhost procedure rds_kill(IN thread bigint)
BEGIN
  DECLARE l_user varchar(16);
  DECLARE l_host varchar(64);
  DECLARE v_semi_sync ENUM('SOURCE', 'REPLICA', 'NO');

  SELECT user, host INTO l_user, l_host
  FROM information_schema.processlist
  WHERE id = thread;

  
  
  
  
  
  
  
  
  
  
  
  
  SELECT mysql.rds_is_semi_sync() INTO v_semi_sync;

  IF l_user = "rdsadmin" AND l_host REGEXP '^localhost(:[0-9]+)?$' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT KILL RDSADMIN SESSION';
  ELSEIF l_user = "rdsrepladmin" THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT KILL RDSREPLADMIN SESSION';
  ELSEIF l_user = "rdstopmgr" AND v_semi_sync != 'NO' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT KILL RDSTOPMGR SESSION';
  ELSE
    KILL THREAD;
  END IF;
END;

